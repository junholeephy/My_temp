{
  gROOT->ProcessLine(".L /afs/cern.ch/work/c/chanon/CMSSW_8_0_23/src/TMVAtests/TMVARegression.cxx++");
  TMVARegression();
}
